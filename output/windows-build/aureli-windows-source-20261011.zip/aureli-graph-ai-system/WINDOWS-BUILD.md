# Windows 本地打包（复用已安装 Aureli 的运行环境）

此源码包包含 2026-10-11 的 Windows 旧锁文件启动修复。

1. 安装 Windows x64 Node.js 24、JDK 21、Apache Maven 3.9.x。
   - Node.js：https://nodejs.org/en/download
   - JDK 21：https://adoptium.net/temurin/releases/?version=21&os=windows&arch=x64
   - Maven：https://maven.apache.org/install.html
   安装 JDK 时设置 JAVA_HOME；把 Maven 的 bin 目录加入 Path，然后重新打开 PowerShell。
2. 将 ZIP 解压到 C:\build，得到 C:\build\aureli-graph-ai-system。
3. 保留旧版 Aureli 安装目录。在旧版快捷方式上右键选择“打开文件所在的位置”，
   找到 Aureli.exe（如先定位到快捷方式，再从快捷方式继续定位程序）。
   记下包含 Aureli.exe 和 resources 文件夹的安装目录。
4. 退出 Aureli。在 PowerShell 中运行下面命令。
   提示输入路径时，粘贴上一步的安装目录，不含 Aureli.exe 文件名。

```powershell
node --version
java -version
mvn.cmd -version
node -p "process.platform + ' ' + process.arch"

$oldApp = (Read-Host '粘贴旧版 Aureli.exe 所在文件夹').Trim('"')
$runtime = Join-Path $oldApp 'resources'
$env:AURELI_JAVA_SOURCE = Join-Path $runtime 'java'
$env:AURELI_POSTGRES_SOURCE = Join-Path $runtime 'postgres'
$env:AURELI_VC_REDIST_SOURCE = Join-Path $runtime 'postgres\bin'
$env:CSC_IDENTITY_AUTO_DISCOVERY = 'false'

Set-Location 'C:\build\aureli-graph-ai-system\desktop'
npm.cmd ci
if ($LASTEXITCODE -ne 0) { throw '依赖安装失败，请先处理上面的错误。' }
npm.cmd run dist:win
```

应显示 Node v24、Java 21、Maven 使用 Java 21，以及 win32 x64。
首次构建需要联网下载 npm 和 Maven 依赖、Electron 和打包工具。
旧版安装目录必须包含 resources/java/bin/java.exe、resources/postgres/bin/postgres.exe、
resources/postgres/lib/vector.dll，以及 PostgreSQL bin 目录内的 Microsoft CRT DLL。
本方案复用同一 PostgreSQL 主版本，避免无意更换已有用户数据库的主版本。

脚本会依次构建前端、创建独立临时数据库运行后端测试并打包 JAR、准备运行环境、
运行桌面测试、生成安装包，并测试打包后的实际运行资源。
无需手动创建业务数据库或填写旧数据库密码，不会打包用户数据库。

必须等整个命令成功结束（看到“安装包已生成”）再使用安装包。
输出：C:\build\aureli-graph-ai-system\desktop\dist\windows\Aureli-Setup-1.0.0-x64.exe

安装后验证：能打开应用；退出后重新打开；重启 Windows 后再打开；原数据仍在。
如构建失败，保留终端最后的错误和提示的日志路径。
